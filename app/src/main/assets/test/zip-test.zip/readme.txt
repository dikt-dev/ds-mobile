这是 ZIP 里的 readme.txt
第二行。